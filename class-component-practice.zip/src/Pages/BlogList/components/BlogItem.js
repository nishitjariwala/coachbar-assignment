import React, { Component } from 'react';

export default class BlogItem extends Component {

    constructor (props) {
        super(props);
        this.state={
            blogData: {}
        }
    }
    static getDerivedStateFromProps (props, state) {
        return {
            blogData: props.blogData
        }
    }
    
    render () {
        const {blogData} = this.state
        console.log(blogData)
        return (
            <div style={{
                // width: '100%',
                border: "2px solid black",
                padding: 5,
                margin: 10
            }}>
                
                <div style={{display: 'flex', }}></div>
            </div>
        )
    }
}

// constructor (props) {
    //     super(props);
    //     this.state={
    //         blogData: {}
    //     }
    // }
    // static getDerivedStateFromProps (props, state) {
    //     return {
    //         blogData: props.blogData
    //     }
    // }