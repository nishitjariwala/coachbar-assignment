import React, { Component } from 'react';
import BlogItem from './components/BlogItem';

export default class BlogList extends Component {

    constructor(props){
        super(props);
        this.state = {
            blogs: []
        }
    }

    static getDerivedStateFromProps = (props, state) => {
        return {
            blogs: props.blogs
        }
    }
    
    render () {
        const {blogs} = this.state
        console.log(blogs)
        return (
            <>
                {
                    blogs.map(blog=><BlogItem blogData={blog} item={blog.id} />)
                }
            </>
        )
    }
}