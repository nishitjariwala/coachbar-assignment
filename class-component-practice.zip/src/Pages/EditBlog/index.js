import React, { Component } from 'react';

export default class EditList extends Component {
    render () {
        return (
            <>Edit List</>
        )
    }
}