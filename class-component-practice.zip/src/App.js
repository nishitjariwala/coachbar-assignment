import logo from './logo.svg';
// import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import BlogList from './Pages/BlogList';
import EditList from './Pages/EditBlog';
import { Component } from 'react';

export default class App extends Component {

  constructor (props) {
    super(props)
    this.state = {
      blogs: []
    }
  }

  componentDidMount(){
    fetch('https://api.slingacademy.com/v1/sample-data/blog-posts')
    .then(data=>data.json())
    .then(data=>{
      // console.log(data)
      this.updateState("blogs", data.blogs)
    })
    .catch(e=>{
      console.log(e)
    })
  }

  updateState (key, value, fun=undefined) {
    this.setState({...this.state, [key]: value}, fun)
  }

  render () {
    const {blogs} = this.state
    // console.log(blogs)
    return (
      <div className="App">
        <Router>
          <Switch>
            <Route exact path="/">
              <BlogList blogs={blogs} />
            </Route>
            <Route exact path="/edit/:topicId">
              <EditList />
            </Route>
            <Route path="*">
              <Redirect to='/' />
            </Route>
          </Switch>
        </Router>
      </div>
    )
  };
}
